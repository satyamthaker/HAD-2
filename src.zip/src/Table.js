import { Component } from "react";

class Table_had extends Component{

}
const Table = () => {
    return(
        <table>
            <thead>
            <tr>
                <th>Student_name</th>
                <th>Roll_no</th>
                <th>Class</th>
            </tr>
            </thead>
                <tbody>
                    <tr>
                        <th>satyam</th>
                        <th>386</th>
                        <th>syit</th>
                    </tr>
                    <tr>
                        <th>abc</th>
                        <th>380</th>
                        <th>syit</th>
                    </tr>
                    </tbody>
                    </table>
    );
}

export default Table; 